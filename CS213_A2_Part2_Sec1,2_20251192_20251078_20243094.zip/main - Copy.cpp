#include <iostream>
#include <string>
#include <iomanip>
#include "VoleMachine.h"

void printMenu() {
    std::cout << "\n==========================================" << std::endl;
    std::cout << "         VOLE MACHINE SIMULATOR           " << std::endl;
    std::cout << "==========================================" << std::endl;
    std::cout << "1. Load Program from File" << std::endl;
    std::cout << "2. Run Program (At Once)" << std::endl;
    std::cout << "3. Execute Step-by-Step" << std::endl;
    std::cout << "4. Modify Register Content" << std::endl;
    std::cout << "5. Modify Memory Cell Content" << std::endl;
    std::cout << "6. Display Machine Status" << std::endl;
    std::cout << "7. Exit" << std::endl;
    std::cout << "Enter choice (1-7): ";
}

int main() {
    VoleMachine vole;
    int choice = 0;

    while (true) {
        printMenu();
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            continue;
        }

        if (choice == 7) {
            std::cout << "Exiting Vole Machine Simulator. Goodbye!\n";
            break;
        }

        switch (choice) {
            case 1: {
                std::string filename, addrHex;
                std::cout << "Enter program filename (e.g., program.txt): ";
                std::cin >> filename;
                std::cout << "Enter start memory address in Hex (even number < FF, e.g., 00, 02): ";
                std::cin >> addrHex;

                int startAddr = std::stoi(addrHex, nullptr, 16);
                if (vole.loadProgramFile(filename, startAddr)) {
                    std::cout << "\n--- Machine Initial State ---" << std::endl;
                    vole.displayStatus();
                }
                break;
            }
            case 2: {
                std::cout << "\nRunning program to completion..." << std::endl;
                vole.runProgram();
                break;
            }
            case 3: {
                std::cout << "\nExecuting single step..." << std::endl;
                vole.stepExecution();
                break;
            }
            case 4: {
                std::string regHex, valHex;
                std::cout << "Enter Register Index (0-F in hex): ";
                std::cin >> regHex;
                std::cout << "Enter New Value (00-FF in hex): ";
                std::cin >> valHex;

                int reg = std::stoi(regHex, nullptr, 16);
                uint8_t val = static_cast<uint8_t>(std::stoi(valHex, nullptr, 16));
                vole.setRegisterValue(reg, val);
                std::cout << "Register updated successfully." << std::endl;
                break;
            }
            case 5: {
                std::string addrHex, valHex;
                std::cout << "Enter Memory Address (00-FF in hex): ";
                std::cin >> addrHex;
                std::cout << "Enter New Value (00-FF in hex): ";
                std::cin >> valHex;

                int addr = std::stoi(addrHex, nullptr, 16);
                uint8_t val = static_cast<uint8_t>(std::stoi(valHex, nullptr, 16));
                vole.setMemoryValue(addr, val);
                std::cout << "Memory cell updated successfully." << std::endl;
                break;
            }
            case 6: {
                vole.displayStatus();
                break;
            }
            default:
                std::cout << "Invalid selection! Please enter a number from 1 to 7." << std::endl;
                break;
        }
    }

    return 0;
}
